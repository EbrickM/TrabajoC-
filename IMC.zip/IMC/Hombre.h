#ifndef HOMBRE_H
#define HOMBRE_H

#include "Persona.h"

class Hombre : public Persona {
public:
    Hombre();

    float calcularIMC() const override;
    void leerDatos() override;
};

#endif // HOMBRE_H
