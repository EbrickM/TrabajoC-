#include "Hombre.h"
#include <iostream>

Hombre::Hombre() : Persona(0, 0) {}

float Hombre::calcularIMC() const {
    return peso / (altura * altura);
}

void Hombre::leerDatos() {
    std::cout << "Ingrese el peso del hombre (kg): ";
    std::cin >> peso;
    std::cout << "Ingrese la altura del hombre (m): ";
    std::cin >> altura;
}
