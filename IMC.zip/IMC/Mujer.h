#ifndef MUJER_H
#define MUJER_H

#include "Persona.h"

class Mujer : public Persona {
public:
    Mujer();

    float calcularIMC() const override;
    void leerDatos() override;
};

#endif // MUJER_H

