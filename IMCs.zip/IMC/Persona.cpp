 #include "Persona.h"

    using  namespace std;

    // Sobrecarga del operador de impresi�n <<
    ostream& operator<<(ostream& os, const Persona& persona) {
        os << "Peso: " << persona.peso << " kg, Altura: " << persona.altura << " m";
        return os;
    }

