#include <iostream>
#include <vector>
#include "Persona.h"
#include "Persona.cpp"
#include "Hombre.h"
#include "Mujer.h"
#include <algorithm> // Para usar std::sort

using namespace std;

int main() {
    vector<Persona*> personas;
    vector<float> imcs;

    Hombre hombre;
    Mujer mujer;

    bool repeat = true;
    do{
        system("cls");
        char opcion;
        cout << "\nDesea agregar una persona? [S/N]: ";
        cin >> opcion ;

        switch (opcion){
        case 'N':
            repeat = false;
            break;
        case 'S':
            char op;
            cout << "\nQue tipo de persona desea agregar? [H/M]: ";
            cin >> op;
            if (op == 'H' or op == 'h'){
                hombre.leerDatos();
                personas.push_back(&hombre);
            }else {mujer.leerDatos(); personas.push_back(&mujer);}
        }

    }while(repeat);
    for (auto & persona : personas) {
        cout << "IMC de la persona: " << persona->calcularIMC() << endl;
        cout << "Detalles de la persona: " << *persona << endl;
        imcs.push_back( persona->calcularIMC());
    }

       float suma_imc = 0;
    for (auto & persona : personas) {
        suma_imc += persona->calcularIMC();
    }
    float promedio_imc = personas.empty() ? 0 : suma_imc / personas.size();

    // Mostrar el promedio de IMC por pantalla
    cout << "El promedio de IMC es: " << promedio_imc << endl;
       // Ordenar el vector de IMCs
    sort(imcs.begin(), imcs.end());

    // Encontrar el IMC m�s alto y m�s bajo utilizando b�squeda binaria
    float imc_mas_alto = imcs.back();
    float imc_mas_bajo = imcs.front();

    // Mostrar los resultados
    cout << "\nEl IMC mas alto es: " << imc_mas_alto << endl;
    cout << "El IMC mas bajo es: " << imc_mas_bajo << endl;

    return 0;
}

