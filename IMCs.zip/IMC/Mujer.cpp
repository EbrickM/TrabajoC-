#include "Mujer.h"
#include <iostream>

Mujer::Mujer() : Persona(0, 0) {}

float Mujer::calcularIMC() const {
    return (peso / (altura * altura))/2;
}

void Mujer::leerDatos() {
    std::cout << "Ingrese el peso de la mujer (kg): ";
    std::cin >> peso;
    std::cout << "Ingrese la altura de la mujer (m): ";
    std::cin >> altura;
}
