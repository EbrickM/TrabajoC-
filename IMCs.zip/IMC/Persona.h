#ifndef PERSONA_H
#define PERSONA_H

#include <iostream>

class Persona {
protected:
    float peso;
    float altura;

public:
    Persona(float _peso, float _altura) : peso(_peso), altura(_altura) {}

    friend std::ostream& operator<<(std::ostream& os, const Persona& persona);

    virtual float calcularIMC() const = 0;
    virtual void leerDatos() = 0;
};

#endif // PERSONA_H

